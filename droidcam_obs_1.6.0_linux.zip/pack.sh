if [ -z "$version" ]; then
	echo export version=1.
	exit
fi
if [ ! -d /mnt/hgfs/tmp/ ]; then
	echo "Missing /mnt/hgfs/tmp"
	exit
fi
set -e

make
zip -j droidcam_obs_${version}_linux.zip linux/*
mv droidcam_obs_${version}_linux.zip ~/.config/obs-studio/plugins
cd ~/.config/obs-studio/plugins
zip -r droidcam_obs_${version}_linux.zip droidcam-obs/
mv droidcam_obs_${version}_linux.zip /mnt/hgfs/tmp
cd -